#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2018-06-18 09:12:34

#include "Arduino.h"
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <EspHttpServer.h>

void setup() ;
void loop() ;

#include "EspHttpConfigServer.ino"


#endif
