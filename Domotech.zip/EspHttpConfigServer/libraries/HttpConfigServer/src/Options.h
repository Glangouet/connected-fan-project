/*
 * Options.h
 *
 *  Created on: 28 mai 2018
 *      Author: Tala
 */

#ifndef SRC_OPTIONS_H_
#define SRC_OPTIONS_H_

#define SERIAL_DEBUG

#endif /* SRC_OPTIONS_H_ */
